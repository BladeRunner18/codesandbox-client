import { FSModule } from './FS';
/**
 * @hidden
 */
declare const _fsMock: FSModule;
export default _fsMock;
