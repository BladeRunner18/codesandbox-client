module.exports = BrowserFS.BFSRequire('buffer');
