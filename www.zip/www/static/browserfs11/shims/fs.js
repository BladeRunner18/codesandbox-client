module.exports = BrowserFS.BFSRequire('fs');
